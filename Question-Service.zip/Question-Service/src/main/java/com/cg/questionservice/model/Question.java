package com.cg.questionservice.model;


import javax.validation.constraints.NotBlank;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection="question_details")
public class Question {
	
	  public static final String SEQUENCE_NAME = null;

	@Id
	  private int id;
	  
	  @NotBlank(message = "qname is mandatory")
	  private String qname;
	 @NotBlank(message = "optionone is mandatory")
	  private String optionOne;
	 @NotBlank(message = "optionTwo is mandatory")
	  private String optionTwo;
	 @NotBlank(message = "optionThree is mandatory")
	  private String optionThree;
	 @NotBlank(message = "optionFour is mandatory")
	  private String optionFour;

}
