package com.cg.questionservice.exception;

@SuppressWarnings("serial")
public class QuestionNotFoundException extends Exception {

	public QuestionNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
