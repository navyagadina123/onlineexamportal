package com.cg.questionservice.exception;

@SuppressWarnings("serial")
public class NoProperDataException extends Exception {

	public NoProperDataException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
