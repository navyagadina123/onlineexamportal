package com.cg.resultservice.exception;

@SuppressWarnings("serial")
public class ResultNotFoundException extends Exception {

	public ResultNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
